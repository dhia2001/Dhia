import 'package:flutter/material.dart';

void main() {
  runApp(SaveItDZ());
}

class SaveItDZ extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SaveIt DZ',
      theme: ThemeData.dark().copyWith(
        primaryColor: Colors.teal,
        scaffoldBackgroundColor: Colors.black,
      ),
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  final TextEditingController linkController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('SaveIt DZ'),
        actions: [
          IconButton(
            icon: Icon(Icons.folder),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => SavedFilesScreen()),
              );
            },
          )
        ],
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: linkController,
              style: TextStyle(color: Colors.white),
              decoration: InputDecoration(
                hintText: 'Paste video link...',
                hintStyle: TextStyle(color: Colors.grey),
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => DownloadScreen()),
                );
              },
              child: Text('Download'),
              style: ElevatedButton.styleFrom(primary: Colors.teal),
            ),
            SizedBox(height: 24),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Icon(Icons.video_library, color: Colors.red),
                Icon(Icons.facebook, color: Colors.blue),
                Icon(Icons.camera_alt, color: Colors.purple),
                Icon(Icons.music_note, color: Colors.pink),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class DownloadScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Download Options')),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Select Quality:', style: TextStyle(fontSize: 18)),
            SizedBox(height: 16),
            Wrap(
              spacing: 10,
              children: [
                ChoiceChip(label: Text('360p'), selected: false),
                ChoiceChip(label: Text('720p'), selected: false),
                ChoiceChip(label: Text('1080p'), selected: false),
                ChoiceChip(label: Text('MP3'), selected: false),
                ChoiceChip(label: Text('M4A'), selected: false),
              ],
            ),
            SizedBox(height: 30),
            Center(
              child: ElevatedButton(
                onPressed: () {},
                child: Text('Start Download'),
                style: ElevatedButton.styleFrom(primary: Colors.teal),
              ),
            )
          ],
        ),
      ),
    );
  }
}

class SavedFilesScreen extends StatelessWidget {
  final List<String> files = ['Mountain Hiking', 'City Lights', 'Podcast Episode', 'Travel Vlog'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Saved Files')),
      body: ListView.builder(
        itemCount: files.length,
        itemBuilder: (context, index) {
          return ListTile(
            leading: Icon(Icons.play_circle_filled, color: Colors.teal),
            title: Text(files[index]),
            subtitle: Text('MP4'),
            trailing: Icon(Icons.more_vert),
          );
        },
      ),
    );
  }
}
